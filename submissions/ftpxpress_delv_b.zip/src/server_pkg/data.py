

class Data(Object):

	def __init__(self):
		pass

	def append(self, message, index):
		pass