

class Preferences(object):

	def __init__(self):
		self.is_secure = None
		self.packet_size = None

	def set_preferences(self):
		pass

	def save_preferences(self):
		pass